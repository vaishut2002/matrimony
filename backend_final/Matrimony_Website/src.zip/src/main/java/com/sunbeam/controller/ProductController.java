package com.sunbeam.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.dto.ApiResponse;
import com.sunbeam.entities.Product;
import com.sunbeam.service.ProductService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	private ProductService productService;
	
	public ProductController() {
		System.out.println("In ctor of product controller");
	}
	
	//get all products
	@GetMapping
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	//Add
	@PostMapping
	public ResponseEntity<?> addProduct(@RequestBody Product newProduct) {
		System.out.println("In add product");
		try {
			 
			return ResponseEntity.status(HttpStatus.CREATED).body(productService.addProduct(newProduct));
			
		}catch(RuntimeException e) {
			System.out.println("err "+e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(e.getMessage()));
		}
	}
	
	//Update
	@PostMapping("/updateProduct/{productId}")
	public ResponseEntity<?> updateProduct(@PathVariable Long productId, @RequestBody Product updatedProduct){
		System.out.println("in update " + productId + " " + updatedProduct);
		try {
			return ResponseEntity.ok(new ApiResponse(productService.updateProduct(productId, updatedProduct)));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage()));
		}
	}
	
	@PostMapping("/deleteProduct/{productId}")
	public ResponseEntity<?> deleteProduct(@PathVariable Long productId){
		System.out.println("in delete " + productId);
		try {
			return ResponseEntity.ok(new ApiResponse(productService.deleteProduct(productId)));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage()));
		}
	}
	
	
	//GetById
	@GetMapping("/{productId}")
	public ResponseEntity<?> getProductDetails(@PathVariable long productId){
		System.out.println("In get details by id");
		return ResponseEntity.ok(productService.getProductById(productId));
	}
}
