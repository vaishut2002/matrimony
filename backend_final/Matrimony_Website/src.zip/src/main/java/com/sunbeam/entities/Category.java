package com.sunbeam.entities;

public enum Category {
	ELECTRONICS, EDUCATIONAL, DOLL, SOUND_TOYS;
}
