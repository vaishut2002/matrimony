package com.sunbeam.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@ToString
public class BaseDTO {
	@JsonProperty(access = Access.READ_ONLY)
	private long id;
	
	@JsonProperty(access = Access.READ_ONLY)
	private LocalDate createdOn;
	
	@JsonProperty(access = Access.READ_ONLY)
	private LocalDate updatedOn;
}
