package com.sunbeam.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="productsTable")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Product extends BaseEntity {
	

	@Column(name="product_name",length=30,unique=true)
	private String productName;
	
	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	private Category category;
	
	private double price;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "customers_id")
	private Customer customer;
	
	public Product(String productName, Category category, double price, Customer customer) {
		super();
		this.productName = productName;
		this.category = category;
		this.price = price;
		this.customer = customer;
	}
}
