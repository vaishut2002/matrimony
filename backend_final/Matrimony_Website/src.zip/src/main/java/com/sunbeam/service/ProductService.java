package com.sunbeam.service;

import java.util.List;

import com.sunbeam.dto.ProductDTO;
import com.sunbeam.entities.*;

public interface ProductService {
	List<Product> getAllProducts();
	
	Product addProduct(Product product);
	
	ProductDTO getProductById(long productId);
	
	String updateProduct(Long productId, Product product);
	
	String deleteProduct(Long productId);
	
	
}
