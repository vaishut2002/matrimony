package com.sunbeam.entities;

public enum Gender {
	MALE,FEMALE
}
