package com.sunbeam.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProductDTO {
	private String productName;
	private String description;
	private double price;
	private int availableQTY;
	private LocalDate expirationDate;
}
