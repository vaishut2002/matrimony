package com.sunbeam.service;

import com.sunbeam.entities.Customer;

public interface CustomerService {
	Customer addCustomer(Customer customer);
	
	
}
